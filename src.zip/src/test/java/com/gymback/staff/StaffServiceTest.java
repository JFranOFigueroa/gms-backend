package com.gymback.staff;
import com.gymback.modules.staff.dto.StaffRequest;
import com.gymback.modules.staff.interfaces.IStaffRepository;
import com.gymback.modules.staff.services.StaffService;
import com.gymback.security.*;
import com.gymback.shared.exceptions.DomainException;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.util.*;

class StaffServiceTest {
  @Test void createsRelationOnlyForExistingActiveUser() {
    var accounts=mock(IIdentityRepository.class);var auth=mock(AuthorizationService.class);
    var staff=mock(IStaffRepository.class);
    UUID user=UUID.randomUUID(),branch=UUID.randomUUID(),actor=UUID.randomUUID();
    when(auth.require(eq(branch),any(String[].class))).thenReturn(new Actor(actor,true));
    when(auth.actor()).thenReturn(new Actor(actor,true));
    when(accounts.findCredentialsById(user)).thenReturn(Optional.of(new IIdentityRepository.UserCredentials(
      user,"Entrenador","coach@example.test","hash","active",null)));
    when(staff.get(branch,user)).thenReturn(Map.of("id",user,"roles",List.of("trainer")));
    var service=new StaffService(auth,accounts,staff);
    assertEquals(user,service.add(branch,new StaffRequest(user,"trainer")).get("id"));
    verify(accounts).assignStaff(user,branch,"trainer",actor);
  }
  @Test void refusesAmbiguousMultiRoleChange() {
    var accounts=mock(IIdentityRepository.class);var auth=mock(AuthorizationService.class);
    UUID user=UUID.randomUUID(),branch=UUID.randomUUID();
    when(accounts.activeStaffRoles(user,branch)).thenReturn(Set.of("owner","trainer"));
    var service=new StaffService(auth,accounts,mock(IStaffRepository.class));
    assertThrows(DomainException.class,()->service.change(branch,user,new StaffRequest(null,"trainer")));
    verify(accounts,never()).deactivateStaff(any(),any());
  }

  @Test void hidesPlatformAdminFromStaff() {
    var accounts=mock(IIdentityRepository.class);var auth=mock(AuthorizationService.class);
    var staff=mock(IStaffRepository.class);
    UUID user=UUID.randomUUID(),branch=UUID.randomUUID(),actor=UUID.randomUUID();
    when(auth.require(eq(branch),any(String[].class))).thenReturn(new Actor(actor,true));
    when(accounts.isPlatformAdmin(user)).thenReturn(true);
    var service=new StaffService(auth,accounts,staff);
    assertThrows(com.gymback.shared.exceptions.NotFoundException.class,
      ()->service.add(branch,new StaffRequest(user,"owner")));
    verify(accounts,never()).assignStaff(any(),any(),anyString(),any());
  }
}
